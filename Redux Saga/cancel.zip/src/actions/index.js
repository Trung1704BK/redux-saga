import { createTask, deleteTask, fetchTasks, cancelFetchTasks } from "./tasks";

var actions = { createTask, deleteTask, fetchTasks, cancelFetchTasks };
export default actions;
