import React from "react";
import ReactDOM from "react-dom";

var element = <div>Hello World</div>;
ReactDOM.render(element, document.getElementById("root"));

console.log(element);
