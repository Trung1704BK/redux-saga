export const fetchTasksWorkerSaga = function*()
{
  console.log("fetch tasks");
};
