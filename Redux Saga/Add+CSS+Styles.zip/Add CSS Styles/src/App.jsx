import React, { Component } from "react";

class NavBar extends Component {
  render() {
    return (
      <React.Fragment>
        <h1>Hello</h1>
        <p class="highlight">paragraph</p>
      </React.Fragment>
    );
  }
}

export default NavBar;
