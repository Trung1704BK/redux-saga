import React from 'react';
import Tasks from "./components/Tasks/Tasks";

function App() {
  return (
    <Tasks />
  )
}

export default App;
