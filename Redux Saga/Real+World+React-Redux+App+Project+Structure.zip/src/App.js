import React from 'react';

function App() {
  return (
    <h1>React</h1>
  )
}

export default App;
