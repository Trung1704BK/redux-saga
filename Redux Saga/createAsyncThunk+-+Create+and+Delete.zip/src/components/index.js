import Contacts from "./Contacts/Contacts";
import NavBar from "./NavBar/NavBar";

export { Contacts, NavBar };
