const usersInitialState = {
  isLoggedIn: false,
  currentUser: null
};

export default usersInitialState;
