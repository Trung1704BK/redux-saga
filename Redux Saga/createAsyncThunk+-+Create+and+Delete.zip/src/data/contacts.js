let contactsInitialState = {
  data: [],
  status: null //pending, fulfilled, rejected
};

export default contactsInitialState;
