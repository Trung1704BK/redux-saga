export const initialTasks = [
  {
    id: 1,
    taskTitle: "Appointment with Bob",
    taskDateTime: "2021-07-16 9:30"
  },
  {
    id: 2,
    taskTitle: "Meeting with contractors",
    taskDateTime: "2022-09-04 15:00"
  },
  {
    id: 3,
    taskTitle: "Some other task",
    taskDateTime: "2021-08-11 10:00"
  }
];
