import { fetchTasksWorkerSaga, createTaskWorkerSaga, deleteTaskWorkerSaga } from  "./tasks.js";
import { fork, takeEvery, takeLatest, throttle } from "redux-saga/effects";
import * as actionTypes from "../constants/action-types";

//receiving actions related to "tasks" table
export const tasksWatcherSaga = function*() {
  yield takeLatest(actionTypes.FETCH_TASKS, fetchTasksWorkerSaga);

  yield throttle(1000 * 30, actionTypes.CREATE_TASK, createTaskWorkerSaga);

  yield takeEvery(actionTypes.DELETE_TASK, deleteTaskWorkerSaga);
};

//receiving actions related to "employees" table
export const employeesWatcherSaga = function*() {
};

export const rootSaga = function*() {
  console.log("rootSaga invoked");

  yield fork(tasksWatcherSaga);
  yield fork(employeesWatcherSaga);
  
  //FETCH_TASKS --> fetchTasksWorkerSaga
};
