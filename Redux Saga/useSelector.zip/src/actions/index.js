import { createTask, deleteTask } from "./tasks";

var actions = { createTask, deleteTask };
export default actions;
