import React from 'react';
import { Contacts } from "./components";

function App() {
  return (
    <Contacts />
  )
}

export default App;
