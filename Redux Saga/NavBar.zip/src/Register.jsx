import React from "react";

let Register = () => {
  return <div>Register</div>;
};

export default Register;
