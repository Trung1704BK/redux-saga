import { createTask, deleteTask, fetchTasks } from "./tasks";

var actions = { createTask, deleteTask, fetchTasks };
export default actions;
