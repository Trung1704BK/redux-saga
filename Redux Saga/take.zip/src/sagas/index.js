import { fetchTasksWorkerSaga, createTaskWorkerSaga, deleteTaskWorkerSaga } from  "./tasks.js";
import { fork, takeEvery, takeLatest, throttle, all, take } from "redux-saga/effects";
import * as actionTypes from "../constants/action-types";

//receiving actions related to "tasks" table
export const tasksWatcherSaga = function*() {
  yield takeLatest(actionTypes.FETCH_TASKS, fetchTasksWorkerSaga);

  //send maximum only one request within 30 seconds
  yield throttle(1000 * 30, actionTypes.CREATE_TASK, createTaskWorkerSaga);

  //wait for CREATE_TASK; and then only proceed to the subsequent code
  yield take(actionTypes.CREATE_TASK);

  yield takeEvery(actionTypes.DELETE_TASK, deleteTaskWorkerSaga);
};

//receiving actions related to "employees" table
export const employeesWatcherSaga = function*() {
};

export const rootSaga = function*() {
  console.log("rootSaga invoked");

  //run multiple watcher sagas in parallel
  yield all([
    fork(tasksWatcherSaga),
    fork(employeesWatcherSaga)
  ]);
};
