import React from "react";

function NoMatchPage() {
  return <h1 className="text-danger">Page not found</h1>;
}

export default NoMatchPage;
