import React, { useEffect } from "react";

let Register = () => {
  //executes only once - on initial render =  componentDidMount
  useEffect(() => {
    document.title = "Register - eCommerce";
  }, []);

  return <div>Register</div>;
};

export default Register;
