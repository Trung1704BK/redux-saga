export const initialTask = [
  {
    id: 1,
    taskTitle: "Appointment with Bob",
    taskDateTime: "2021-07-16 9:30"
  },
  {
    id: 2,
    taskTitle: "Meeting with contractors",
    taskDateTime: "2022-09-04 15:00"
  },
];
